日本語話者sol廃向け　マウスのお供連携ツール - hallcuie
v2 2026-07-13

テスト環境：
・Windows 11 Pro 64bit
・マウスのお供 ver.1.68.26 [2026/06/28] (x64)

これはなに：
マウスのお供 の外部連携機能を利用して、IME状態とSol's RNGのバイオームを表示します。
所謂レアバイオーム（GLITCHED、DREAMSPACE、CYBERSPACE、SINGULARITY）を検知した際、Webhook経由でDiscordに通知を飛ばします。@everyoneメンションします。

settings.ini(書かなくてもDiscord通知以外は動作します)
webhookURL：ここにDiscord WebhookURL
privateServerLink：ここにRobloxのプラベ鯖リンク

サポート：
なし